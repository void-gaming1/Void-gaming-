let loginMode=false;
const $=id=>document.getElementById(id);
function openAuth(){$("modal").style.display="flex"}
function closeAuth(){$("modal").style.display="none"}
function toggle(){loginMode=!loginMode;$("title").textContent=loginMode?"Login":"Create account";$("submit").textContent=loginMode?"Login":"Create account";$("switch").textContent=loginMode?"Need an account? Create one":"Already have an account? Login";$("username").style.display=loginMode?"none":"block"}
async function api(url,body){let r=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});let j=await r.json();if(!r.ok)throw Error(j.error||"Request failed");return j}
async function submitAuth(){try{$("msg").textContent="";let data=loginMode?{email:$("email").value,password:$("password").value}:{username:$("username").value,email:$("email").value,password:$("password").value};await api(loginMode?"/api/login":"/api/register",data);closeAuth();loadMe()}catch(e){$("msg").textContent=e.message}}
async function loadMe(){let j=await fetch("/api/me").then(r=>r.json());if(j.user){$("account").textContent=`Logged in as ${j.user.username} (${j.user.email})`;$("logout").style.display="inline-block"}else{$("account").textContent="Not logged in.";$("logout").style.display="none"}}
async function logout(){await fetch("/api/logout",{method:"POST"});loadMe()}
async function loadServer(){let j=await fetch("/api/server-status").then(r=>r.json());$("server").innerHTML=j.online?`<span class="good">ONLINE</span> • ${j.players.online}/${j.players.max} players • ${j.latency}ms • ${j.version}`:`<span style="color:#f87171">OFFLINE / UNREACHABLE</span> • ${j.host}:${j.port}`}
loadMe();loadServer();setInterval(loadServer,30000);
