const express = require("express");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const session = require("express-session");
const path = require("path");
const { status } = require("minecraft-server-util");

const app = express();
const PORT = process.env.PORT || 3000;
const MC_HOST = process.env.MC_HOST || "play.voidgaming.net";
const MC_PORT = Number(process.env.MC_PORT || 25565);

const db = new Database("void-gaming.db");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));
app.use(session({
  secret: process.env.SESSION_SECRET || "CHANGE_THIS_IN_PRODUCTION",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: false, maxAge: 1000*60*60*24*7 }
}));

function clean(s) { return typeof s === "string" ? s.trim() : ""; }

app.post("/api/register", async (req,res)=>{
  const username = clean(req.body.username);
  const email = clean(req.body.email).toLowerCase();
  const password = req.body.password || "";
  if (!/^[A-Za-z0-9_]{3,20}$/.test(username))
    return res.status(400).json({error:"Username must be 3–20 letters, numbers or underscores."});
  if (!/^\S+@\S+\.\S+$/.test(email))
    return res.status(400).json({error:"Enter a valid email."});
  if (password.length < 8)
    return res.status(400).json({error:"Password must be at least 8 characters."});
  try {
    const hash = await bcrypt.hash(password, 12);
    const info = db.prepare("INSERT INTO users (username,email,password_hash) VALUES (?,?,?)")
      .run(username,email,hash);
    req.session.user = {id: info.lastInsertRowid, username, email};
    res.json({user:req.session.user});
  } catch(e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({error:"Username or email already exists."});
    res.status(500).json({error:"Could not create account."});
  }
});

app.post("/api/login", async (req,res)=>{
  const email = clean(req.body.email).toLowerCase();
  const password = req.body.password || "";
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!user || !(await bcrypt.compare(password,user.password_hash)))
    return res.status(401).json({error:"Invalid email or password."});
  req.session.user = {id:user.id, username:user.username, email:user.email};
  res.json({user:req.session.user});
});

app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",(req,res)=>res.json({user:req.session.user || null}));

app.get("/api/server-status", async (req,res)=>{
  try {
    const s = await status(MC_HOST, MC_PORT, {timeout: 4000});
    res.json({
      online:true, host:MC_HOST, port:MC_PORT,
      players:{online:s.players.online, max:s.players.max},
      version:s.version.name, latency:s.roundTripLatency
    });
  } catch(e) {
    res.json({online:false, host:MC_HOST, port:MC_PORT, players:{online:0,max:0}, error:"Server unavailable"});
  }
});

app.listen(PORT, ()=>console.log(`VOID GAMING running at http://localhost:${PORT}`));
