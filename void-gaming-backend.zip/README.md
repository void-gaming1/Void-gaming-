# VOID GAMING — real backend starter

## What this adds
- Real SQLite user database
- Password hashing with bcrypt
- Session-based login/logout
- `/api/me` current-user endpoint
- Live Minecraft Java server status through `minecraft-server-util`

## Run
1. Install Node.js 18+.
2. In this folder run:
   `npm install`
3. Set environment variables:
   - `SESSION_SECRET` = a long random secret
   - `MC_HOST` = your actual Minecraft Java server hostname
   - `MC_PORT` = normally `25565`
4. Run:
   `npm start`
5. Open `http://localhost:3000`

## Important
The supplied site must use the API endpoints shown in `public/app.js`.
For production, use HTTPS, a strong secret, secure cookies, rate limiting, CSRF protection, and a managed database/backups.

The live status endpoint is for Minecraft Java servers. Bedrock needs a different status method.
